# GoodNotes-Präsentationsgenerator

Erzeugt aus einem leeren Arbeitsblatt (PDF) und dem dazugehörigen Lösungsblatt
(PDF) automatisch eine `.goodnotes`-Präsentationsdatei: das Lösungsblatt wird
zum Seitenhintergrund, jede erkannte Antwort bekommt einen deckenden weißen
"Abdeck-Strich" (geklont aus echten GoodNotes-Strichen), den du live im
Unterricht wegradierst, um die Lösung zum Vergleich aufzudecken.

Ausführliche Anleitung, Video-freie Schritt-für-Schritt-Erklärung, Hinweise
zur Nutzung mit KI-Chatbots (kostenlos vs. Pro) sowie eine Einschätzung zur
rechtlichen Seite: siehe die begleitende Seite auf ClassroomSpark /
`goodnotes-praesentation-generator.html`.

## Kurzanleitung (lokal, mit eigenem Python)

```bash
pip3 install pymupdf

# Diff-Modus: leeres Arbeitsblatt + Lösungsblatt nebeneinander
python3 generate_goodnotes.py \
  "Arbeitsblatt.pdf" \
  "Lösungsblatt-Arbeitsblatt.pdf" \
  "Präsentation-Arbeitsblatt" \
  "Präsentation-Arbeitsblatt.goodnotes"

# Farb-Modus: Lösungen sind in einer Datei bereits farbig markiert
python3 generate_goodnotes.py \
  "Arbeitsblatt mit Lösungen.pdf" \
  "Präsentation-Arbeitsblatt" \
  "Präsentation-Arbeitsblatt.goodnotes" \
  --color EC008C
```

Voraussetzung: Python 3 mit `pymupdf` (`pip3 install pymupdf`).

## Wichtig, bevor du eine frisch erzeugte Datei im Unterricht einsetzt

Das ist eine selbst zurückentwickelte Implementierung eines nicht
dokumentierten, proprietären Dateiformats. Öffne jede neu erzeugte Datei
einmal testweise in GoodNotes, bevor du dich im Unterricht darauf verlässt.
Seitenreihenfolge (Oktober 2026 behoben): GoodNotes sortiert die Seiten nach
einem kurzen Sortierschlüssel je Seite (Feld 4 von CreateNoteVersion, Vergleich
nach ASCII). Früher wurde er zufällig vergeben, daher die durcheinandergeratenen
mehrseitigen Dateien; jetzt ist er aufsteigend. Mehrseitige PDFs werden außerdem
seitenweise aufgebaut (eigener Anhang je Seite), wie eine auf dem iPad
zusammengefügte Datei; der frühere Aufbau ist mit `--shared-attachment` wählbar.
Die Reihenfolge nach dem Import trotzdem einmal kurz prüfen.

## Lizenz / Nutzung

Frei nutzbar und anpassbar für den eigenen Unterricht. Kein Teil dieses
Werkzeugs enthält GoodNotes-eigenen Code oder urheberrechtlich geschützte
Inhalte von GoodNotes - nur die Struktur des von GoodNotes selbst erzeugten
Dateiformats wurde durch Beobachtung eigener, selbst erstellter Dateien
nachvollzogen (siehe Erklärseite für Details zur rechtlichen Einordnung).
